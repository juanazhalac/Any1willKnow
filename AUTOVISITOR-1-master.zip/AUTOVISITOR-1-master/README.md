*Update : 25 September 2018*

Perhaps the name  "Auto Visitor " it's not too foreign to the bloggers, many of the bloggers who use tools or software Auto Visitor.

Auto-lift program is Visitor traffic on your blog, using a BOT to visit the blog. Indeed this use can increase blog traffic dramatically, from hundreds to thousands of impressions can be.

# For Windows
- Install XAMPP
- Download https://github.com/IDSYSTEM404/AUTOVISITOR
- usage : php autovisitor.php

# For Termux or Linux
- pkg install php
- git clone https://github.com/IDSYSTEM404/AUTOVISITOR
- cd AUTOVISITOR
- php autovisitor.php
